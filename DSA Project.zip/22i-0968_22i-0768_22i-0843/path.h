//#include <SFML/Graphics.hpp>
//#include <iostream>
//#include<stack>
//#include<set>
//#include "map.h"
//using namespace std;
//
//#define ROW 25
//#define COL 25
//
//typedef pair<int, int> Pair;
//typedef pair<double, pair<int, int> > pPair;
//
//struct cell {
//	int parent_i, parent_j;
//	double f, g, h;
//};
//
//bool isValid(int row, int col) {
//	return (row >= 0) && (row < ROW) && (col >= 0) && (col < COL);
//}
//
//bool isUnBlocked(int** grid, int row, int col) {
//	if (grid[row][col] == 1)
//		return (true);
//	else
//		return (false);
//}
//
//bool isDestination(int row, int col, Pair dest) {
//	if (row == dest.first && col == dest.second)
//		return (true);
//	else
//		return (false);
//}
//
//double calculateHValue(int row, int col, Pair dest) {
//	return ((double)sqrt((row - dest.first) * (row - dest.first) + (col - dest.second) * (col - dest.second)));
//}
//
//void tracePath(cell cellinfo[][COL], Pair dest, int**& grid, int gameMap[]) {
//	int row = dest.first;
//	int col = dest.second;
//	stack<Pair> Path;
//
//	while (!(cellinfo[row][col].parent_i == row && cellinfo[row][col].parent_j == col)) {
//		Path.push(make_pair(row, col));
//		int temp_row = cellinfo[row][col].parent_i;
//		int temp_col = cellinfo[row][col].parent_j;
//		row = temp_row;
//		col = temp_col;
//	}
//
//	Path.push(make_pair(row, col));
//	while (!Path.empty()) {
//		pair<int, int> p = Path.top();
//		Path.pop();
//		grid[p.first][p.second] = 9;
//	}
//	int counter = 0;
//	for (int i = 0; i < ROW; i++) {
//		for (int j = 0; j < COL; j++) {
//			gameMap[counter++] = grid[i][j];
//		}
//	}
//	return;
//}
//
//void aStarSearch(int gameMap[], Pair src, Pair dest) {
//	int** grid = new int* [ROW];
//	for (int i = 0; i < ROW; i++)
//		grid[i] = new int[COL];
//
//	int counter = 0;
//	for (int i = 0; i < ROW; i++) {
//		for (int j = 0; j < COL; j++) {
//			grid[i][j] = gameMap[counter++];
//		}
//	}
//
//	if (isValid(src.first, src.second) == false) {
//		return;
//	}
//
//	if (isValid(dest.first, dest.second) == false) {
//		return;
//	}
//
//	if (isUnBlocked(grid, src.first, src.second) == false || isUnBlocked(grid, dest.first, dest.second) == false) {
//		return;
//	}
//
//	if (isDestination(src.first, src.second, dest) == true) {
//		return;
//	}
//
//	bool closedList[ROW][COL];
//	memset(closedList, false, sizeof(closedList));
//	cell cellinfo[ROW][COL];
//
//	int i, j;
//
//	for (i = 0; i < ROW; i++) {
//		for (j = 0; j < COL; j++) {
//			cellinfo[i][j].f = FLT_MAX;
//			cellinfo[i][j].g = FLT_MAX;
//			cellinfo[i][j].h = FLT_MAX;
//			cellinfo[i][j].parent_i = -1;
//			cellinfo[i][j].parent_j = -1;
//		}
//	}
//
//	i = src.first, j = src.second;
//	cellinfo[i][j].f = 0.0;
//	cellinfo[i][j].g = 0.0;
//	cellinfo[i][j].h = 0.0;
//	cellinfo[i][j].parent_i = i;
//	cellinfo[i][j].parent_j = j;
//
//	set<pPair> openList;
//	openList.insert(make_pair(0.0, make_pair(i, j)));
//
//	bool destfound = false;
//
//	while (!openList.empty()) {
//		pPair p = *openList.begin();
//		openList.erase(openList.begin());
//		i = p.second.first;
//		j = p.second.second;
//		closedList[i][j] = true;
//
//		double gNew, hNew, fNew;
//
//		if (isValid(i - 1, j) == true) {
//			if (isDestination(i - 1, j, dest) == true) {
//				cellinfo[i - 1][j].parent_i = i;
//				cellinfo[i - 1][j].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//			else if (closedList[i - 1][j] == false
//				&& isUnBlocked(grid, i - 1, j)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.0;
//				hNew = calculateHValue(i - 1, j, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i - 1][j].f == FLT_MAX
//					|| cellinfo[i - 1][j].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i - 1, j)));
//
//					cellinfo[i - 1][j].f = fNew;
//					cellinfo[i - 1][j].g = gNew;
//					cellinfo[i - 1][j].h = hNew;
//					cellinfo[i - 1][j].parent_i = i;
//					cellinfo[i - 1][j].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i + 1, j) == true) {
//			if (isDestination(i + 1, j, dest) == true) {
//				cellinfo[i + 1][j].parent_i = i;
//				cellinfo[i + 1][j].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//			else if (closedList[i + 1][j] == false
//				&& isUnBlocked(grid, i + 1, j)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.0;
//				hNew = calculateHValue(i + 1, j, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i + 1][j].f == FLT_MAX
//					|| cellinfo[i + 1][j].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i + 1, j)));
//					cellinfo[i + 1][j].f = fNew;
//					cellinfo[i + 1][j].g = gNew;
//					cellinfo[i + 1][j].h = hNew;
//					cellinfo[i + 1][j].parent_i = i;
//					cellinfo[i + 1][j].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i, j + 1) == true) {
//			if (isDestination(i, j + 1, dest) == true) {
//				cellinfo[i][j + 1].parent_i = i;
//				cellinfo[i][j + 1].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//
//			else if (closedList[i][j + 1] == false
//				&& isUnBlocked(grid, i, j + 1)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.0;
//				hNew = calculateHValue(i, j + 1, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i][j + 1].f == FLT_MAX
//					|| cellinfo[i][j + 1].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i, j + 1)));
//
//					cellinfo[i][j + 1].f = fNew;
//					cellinfo[i][j + 1].g = gNew;
//					cellinfo[i][j + 1].h = hNew;
//					cellinfo[i][j + 1].parent_i = i;
//					cellinfo[i][j + 1].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i, j - 1) == true) {
//			if (isDestination(i, j - 1, dest) == true) {
//				cellinfo[i][j - 1].parent_i = i;
//				cellinfo[i][j - 1].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//
//			else if (closedList[i][j - 1] == false
//				&& isUnBlocked(grid, i, j - 1)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.0;
//				hNew = calculateHValue(i, j - 1, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i][j - 1].f == FLT_MAX
//					|| cellinfo[i][j - 1].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i, j - 1)));
//
//					cellinfo[i][j - 1].f = fNew;
//					cellinfo[i][j - 1].g = gNew;
//					cellinfo[i][j - 1].h = hNew;
//					cellinfo[i][j - 1].parent_i = i;
//					cellinfo[i][j - 1].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i - 1, j + 1) == true) {
//			if (isDestination(i - 1, j + 1, dest) == true) {
//				cellinfo[i - 1][j + 1].parent_i = i;
//				cellinfo[i - 1][j + 1].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//
//			else if (closedList[i - 1][j + 1] == false
//				&& isUnBlocked(grid, i - 1, j + 1)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.414;
//				hNew = calculateHValue(i - 1, j + 1, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i - 1][j + 1].f == FLT_MAX
//					|| cellinfo[i - 1][j + 1].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i - 1, j + 1)));
//
//					cellinfo[i - 1][j + 1].f = fNew;
//					cellinfo[i - 1][j + 1].g = gNew;
//					cellinfo[i - 1][j + 1].h = hNew;
//					cellinfo[i - 1][j + 1].parent_i = i;
//					cellinfo[i - 1][j + 1].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i - 1, j - 1) == true) {
//			if (isDestination(i - 1, j - 1, dest) == true) {
//				cellinfo[i - 1][j - 1].parent_i = i;
//				cellinfo[i - 1][j - 1].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//
//			else if (closedList[i - 1][j - 1] == false
//				&& isUnBlocked(grid, i - 1, j - 1)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.414;
//				hNew = calculateHValue(i - 1, j - 1, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i - 1][j - 1].f == FLT_MAX
//					|| cellinfo[i - 1][j - 1].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i - 1, j - 1)));
//					cellinfo[i - 1][j - 1].f = fNew;
//					cellinfo[i - 1][j - 1].g = gNew;
//					cellinfo[i - 1][j - 1].h = hNew;
//					cellinfo[i - 1][j - 1].parent_i = i;
//					cellinfo[i - 1][j - 1].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i + 1, j + 1) == true) {
//			if (isDestination(i + 1, j + 1, dest) == true) {
//				cellinfo[i + 1][j + 1].parent_i = i;
//				cellinfo[i + 1][j + 1].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//
//			else if (closedList[i + 1][j + 1] == false
//				&& isUnBlocked(grid, i + 1, j + 1)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.414;
//				hNew = calculateHValue(i + 1, j + 1, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i + 1][j + 1].f == FLT_MAX
//					|| cellinfo[i + 1][j + 1].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i + 1, j + 1)));
//
//					cellinfo[i + 1][j + 1].f = fNew;
//					cellinfo[i + 1][j + 1].g = gNew;
//					cellinfo[i + 1][j + 1].h = hNew;
//					cellinfo[i + 1][j + 1].parent_i = i;
//					cellinfo[i + 1][j + 1].parent_j = j;
//				}
//			}
//		}
//
//		if (isValid(i + 1, j - 1) == true) {
//			if (isDestination(i + 1, j - 1, dest) == true) {
//				cellinfo[i + 1][j - 1].parent_i = i;
//				cellinfo[i + 1][j - 1].parent_j = j;
//				tracePath(cellinfo, dest, grid, gameMap);
//				destfound = true;
//				return;
//			}
//
//			else if (closedList[i + 1][j - 1] == false
//				&& isUnBlocked(grid, i + 1, j - 1)
//				== true) {
//				gNew = cellinfo[i][j].g + 1.414;
//				hNew = calculateHValue(i + 1, j - 1, dest);
//				fNew = gNew + hNew;
//
//				if (cellinfo[i + 1][j - 1].f == FLT_MAX
//					|| cellinfo[i + 1][j - 1].f > fNew) {
//					openList.insert(make_pair(
//						fNew, make_pair(i + 1, j - 1)));
//
//					cellinfo[i + 1][j - 1].f = fNew;
//					cellinfo[i + 1][j - 1].g = gNew;
//					cellinfo[i + 1][j - 1].h = hNew;
//					cellinfo[i + 1][j - 1].parent_i = i;
//					cellinfo[i + 1][j - 1].parent_j = j;
//				}
//			}
//		}
//	}
//
//	if (destfound == false)
//		return;
//}
//
