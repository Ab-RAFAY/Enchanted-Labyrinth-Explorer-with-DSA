#pragma once
#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <ctime>

using namespace std;
using namespace sf;

class MainMenu {
private:
    RenderWindow window;
    Texture menuTexture;
    Sprite menuSprite;
    bool displayMenu;

public:
    MainMenu();
    void run();
};

MainMenu::MainMenu() : window(VideoMode(1600, 1000), "SFML Game Grid"), displayMenu(true) {
    srand(time(0) * 1000);

    if (!menuTexture.loadFromFile("menuu.png")) {
        cout << "Failed to load menu texture!" << endl;
    }

    menuSprite.setTexture(menuTexture);
    menuSprite.setScale(0.7, 0.8);
    menuSprite.setPosition(150, 50);
}

void MainMenu::run() {
    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }

            if (Keyboard::isKeyPressed(Keyboard::P)) {
                window.clear();
                displayMenu = false;// Update the flag to switch to the game grid
                window.close();
            }

            // Handle other events and game logic
        }

        // Clear the window
        window.clear();

        // Render menu or game grid
        if (displayMenu) {
            // Render menu
            window.draw(menuSprite);
        }

        // Display the window
        window.display();
    }
}