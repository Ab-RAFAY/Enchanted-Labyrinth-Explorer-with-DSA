#pragma once
const int tileSize = 40;
const int gridWidth = 25;
const int gridHeight = 25;

///
/*
class information {
private:
    sf::Font font;
    sf::Text info[Max];

public:
    information(float width, float height);
    void draw(sf::RenderWindow& window, int x);
    void draw1(sf::RenderWindow& window, int x);
    void draw2(sf::RenderWindow& window, int x);
    void draw3(sf::RenderWindow& window, int x);

};

information::information(float width, float height)
{
    if (!font.loadFromFile("britannic.ttf"))
    {
        cout << "Font Not Avalaible..!";
    }

    //Exit Button
    info[0].setFont(font);
    info[0].setFillColor(sf::Color::White);
    info[0].setString("Coins");
    info[0].setCharacterSize(30);
    info[0].setPosition(1030, 50);

    //Play Button
    info[1].setFont(font);
    info[1].setFillColor(sf::Color::Red);
    info[1].setString("Health");
    info[1].setCharacterSize(50);
    info[1].setPosition(1030, 260);


    //Option Button
    info[2].setFont(font);
    info[2].setFillColor(sf::Color::Yellow);
    info[2].setString("Points");
    info[2].setCharacterSize(50);
    info[2].setPosition(1030, 400);

    //About Button
    info[3].setFont(font);
    info[3].setFillColor(sf::Color::Cyan);
    info[3].setString("Inventory");
    info[3].setCharacterSize(50);
    info[3].setPosition(1030, 550);

    info[4].setFont(font);
    info[4].setFillColor(sf::Color::White);
    info[4].setString("Swords");
    info[4].setCharacterSize(30);
    info[4].setPosition(1030, 130);

    info[5].setFont(font);
    info[5].setFillColor(sf::Color::White);
    info[5].setString("Potion");
    info[5].setCharacterSize(30);
    info[5].setPosition(1030, 210);

}

void information::draw1(sf::RenderWindow& window, int coins)
{
    // Update the text for "Coins Collected"
    info[0].setString("Coins: " + std::to_string(coins));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

void information::draw2(sf::RenderWindow& window, int swords)
{
    // Update the text for "Coins Collected"
    info[4].setString("Swords: " + std::to_string(swords));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

void information::draw3(sf::RenderWindow& window, int potion)
{
    // Update the text for "Coins Collected"
    info[5].setString("Potion: " + std::to_string(potion));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

void information::draw(sf::RenderWindow& window, int coinsCollected)
{
    // Update the text for "Coins Collected"
    info[2].setString("Coins Collected: " + std::to_string(coinsCollected));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}
*/