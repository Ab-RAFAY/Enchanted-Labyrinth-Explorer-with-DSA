#pragma once
#include <iostream>
#include <stdexcept>

using namespace std;

template<typename T>
class AVLTree
{
private:
    struct AVLNode
    {
        T data;
        int coinsCount;
        int swordsCount;
        int potionCount;
        int keyCount;
        AVLNode* left;
        AVLNode* right;
        int height;

        AVLNode(const T& newData) : data(newData), coinsCount(0), swordsCount(0), potionCount(0), keyCount(0), left(nullptr), right(nullptr), height(1) {}
    };

    AVLNode* root;

    int height(AVLNode* node) {
        if (node == nullptr)
            return 0;
        return node->height;
    }

    int balanceFactor(AVLNode* node) {
        if (node == nullptr)
            return 0;
        return height(node->left) - height(node->right);
    }

    void updateHeight(AVLNode* node) {
        node->height = 1 + max(height(node->left), height(node->right));
    }

    AVLNode* rightRotate(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;

        x->right = y;
        y->left = T2;

        updateHeight(y);
        updateHeight(x);

        return x;
    }

    AVLNode* leftRotate(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;

        y->left = x;
        x->right = T2;

        updateHeight(x);
        updateHeight(y);

        return y;
    }

    AVLNode* insertNode(AVLNode* node, const T& newData) {
        if (node == nullptr)
            return new AVLNode(newData);

        if (newData < node->data)
            node->left = insertNode(node->left, newData);
        else if (newData > node->data)
            node->right = insertNode(node->right, newData);
        else
            updatecount(node, newData);

        updateHeight(node);

        int balance = balanceFactor(node);

        if (balance > 1 && newData < node->left->data)
            return rightRotate(node);

        if (balance < -1 && newData > node->right->data)
            return leftRotate(node);

        if (balance > 1 && newData > node->left->data) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        if (balance < -1 && newData < node->right->data) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    void updatecount(AVLNode* node, const T& newData)
    {
        if (newData == 10)
        {
            AVLNode* temp = findNode(node, 10);
            cout << "Coins updated " << (temp->coinsCount + 1) << endl;
            updateCoinsCount(10, (temp->coinsCount + 1));
        }

        else if (newData == 20)
        {
            AVLNode* temp = findNode(node, 20);
            cout << "Swords updated " << (temp->swordsCount + 1) << endl;
            updateSwordsCount(20, (temp->swordsCount + 1));
        }

        else if (newData == 30)
        {
            AVLNode* temp = findNode(node, 30);
            cout << "Potion updated " << (temp->potionCount + 1) << endl;
            updatePotionCount(30, (temp->potionCount + 1));
        }

        else if (newData == 3)
        {
            AVLNode* temp = findNode(node, 3);
            cout << "Keys updated " << (temp->keyCount + 1) << endl;
            updatekeyCount(3, (temp->keyCount + 1));
        }
    }

    void removeNode(AVLNode*& node, const T& key) {
        if (node == nullptr)
            return;

        if (key < node->data)
            removeNode(node->left, key);
        else if (key > node->data)
            removeNode(node->right, key);
        else {
            if (node->left == nullptr || node->right == nullptr) {
                AVLNode* temp = node->left ? node->left : node->right;
                if (temp == nullptr) {
                    temp = node;
                    node = nullptr;
                }
                else
                    *node = *temp;
                delete temp;
            }
            else {
                AVLNode* temp = minValueNode(node->right);
                node->data = temp->data;
                removeNode(node->right, temp->data);
            }
        }

        if (node == nullptr)
            return;

        updateHeight(node);

        int balance = balanceFactor(node);

        if (balance > 1 && balanceFactor(node->left) >= 0)
            node = rightRotate(node);

        if (balance > 1 && balanceFactor(node->left) < 0) {
            node->left = leftRotate(node->left);
            node = rightRotate(node);
        }

        if (balance < -1 && balanceFactor(node->right) <= 0)
            node = leftRotate(node);

        if (balance < -1 && balanceFactor(node->right) > 0) {
            node->right = rightRotate(node->right);
            node = leftRotate(node);
        }
    }

    AVLNode* minValueNode(AVLNode* node) {
        AVLNode* current = node;
        while (current->left != nullptr)
            current = current->left;
        return current;
    }

    void balance(AVLNode*& node, int key) {
        if (node == nullptr)
            return;

        int balance = balanceFactor(node);

        if (balance > 1 && key < node->left->data) {
            node = rightRotate(node);
            return;
        }

        if (balance < -1 && key > node->right->data) {
            node = leftRotate(node);
            return;
        }

        if (balance > 1 && key > node->left->data) {
            node->left = leftRotate(node->left);
            node = rightRotate(node);
            return;
        }

        if (balance < -1 && key < node->right->data) {
            node->right = rightRotate(node->right);
            node = leftRotate(node);
            return;
        }
    }

public:
    AVLTree() : root(nullptr) {}

    void insert(const T& newData) {
        root = insertNode(root, newData);
        balance(root, newData);
    }

    void remove(const T& key)
    {
        removeNode(root, key);
    }

    int height() {
        return height(root);
    }

    int balanceFactor() {
        return balanceFactor(root);
    }

    void inOrderTraversal() {
        inOrderTraversal(root);
    }

    void preOrderTraversal() {
        preOrderTraversal(root);
    }

    void postOrderTraversal() {
        postOrderTraversal(root);
    }

    T findSmallest() {
        AVLNode* smallest = minValueNode(root);
        if (smallest)
            return smallest->data;
        else
            throw std::runtime_error("Tree is empty");
    }

    T findLargest() {
        AVLNode* largest = findLargestNode(root);
        if (largest)
            return largest->data;
        else
            throw std::runtime_error("Tree is empty");
    }

    // Function to update the count of coins for a given data
    void updateCoinsCount(const T& data, int count) {
        AVLNode* node = findNode(root, data);
        if (node)
            node->coinsCount = count;
    }

    // Function to update the count of swords for a given data
    void updateSwordsCount(const T& data, int count) {
        AVLNode* node = findNode(root, data);
        if (node)
            node->swordsCount = count;
    }

    // Function to update the count of potions for a given data
    void updatePotionCount(const T& data, int count) {
        AVLNode* node = findNode(root, data);
        if (node)
            node->potionCount = count;
    }

    void updatekeyCount(const T& data, int count)
    {
        AVLNode* node = findNode(root, data);
        if (node)
            node->keyCount = count;
    }

    // Function to get the count of coins for a given data
    int getCoinsCount(T data) {
        AVLNode* node = findNode(root, data);
        return node ? node->coinsCount : 0;
    }

    // Function to get the count of swords for a given data
    int getSwordsCount(T data) {
        AVLNode* node = findNode(root, data);
        return node ? node->swordsCount : 0;
    }

    // Function to get the count of potions for a given data
    int getPotionCount(T data) {
        AVLNode* node = findNode(root, data);
        return node ? node->potionCount : 0;
    }

    int getkeyCount(T data)
    {
        AVLNode* node = findNode(root, data);
        return node ? node->keyCount : 0;
    }

private:
    void inOrderTraversal(AVLNode* node) {
        if (node != nullptr) {
            inOrderTraversal(node->left);
            cout << node->data << " ";
            inOrderTraversal(node->right);
        }
    }

    void preOrderTraversal(AVLNode* node) {
        if (node != nullptr) {
            cout << node->data << " ";
            preOrderTraversal(node->left);
            preOrderTraversal(node->right);
        }
    }

    void postOrderTraversal(AVLNode* node) {
        if (node != nullptr) {
            postOrderTraversal(node->left);
            postOrderTraversal(node->right);
            cout << node->data << " ";
        }
    }

    AVLNode* findSmallestNode(AVLNode* node) {
        AVLNode* current = node;
        while (current && current->left != nullptr)
            current = current->left;
        return current;
    }

    AVLNode* findLargestNode(AVLNode* node) {
        AVLNode* current = node;
        while (current && current->right != nullptr)
            current = current->right;
        return current;
    }

    AVLNode* findNode(AVLNode* node, const T& data) {
        if (node == nullptr)
            return nullptr;

        if (data < node->data)
            return findNode(node->left, data);
        else if (data > node->data)
            return findNode(node->right, data);
        else
            return node;
    }
};
