#pragma once
#include <SFML/Graphics.hpp>
#include<iostream>
using namespace std;
using namespace sf;

//TILES
Texture tileTexture;
Texture tileTexture2;
Texture tileTexture3;
Texture tileTexture4;
Texture tileTexture5;
Texture tileTexture6;
Texture tileTexture7;

//2 more enemies
Texture tileTexture8;
Texture tileTexture9;

//INVENTORY
Texture inventory1;
Texture inventory2;
Texture inventory3;
Texture inventory4;

//Display
Texture texture1;
Texture texture2;
Texture texture3;
Texture texture4;
Texture texture5;
Texture texture6;



void LoadTextures()
{
    if (!tileTexture.loadFromFile("block.png")) {
        cout << "cannot open file!\n";
    }
    if (!tileTexture2.loadFromFile("fire.jpg")) {
        cout << "cannot open file!\n";
    }
    if (!tileTexture3.loadFromFile("player.png")) {
        cout << "cannot open file!\n";
    }
    tileTexture4.loadFromFile("enemy.png");
    tileTexture5.loadFromFile("coins.png");
    tileTexture6.loadFromFile("sword.png");
    tileTexture7.loadFromFile("portion.png");


    tileTexture8.loadFromFile("enemy1.png");
    tileTexture9.loadFromFile("enemy2.png");


    inventory1.loadFromFile("coin.png");
    inventory2.loadFromFile("sword.png");
    inventory3.loadFromFile("portion.png");
    inventory4.loadFromFile("key.png");

    //texture1.loadFromFile("coins.png");
    texture2.loadFromFile("red.png");
    texture3.loadFromFile("path.png");
    texture4.loadFromFile("hint.png");
    texture5.loadFromFile("bar.png");
    texture6.loadFromFile("barFiller.png");

}

