#pragma once
#pragma once
#ifndef MAINMENU_H
#define MAINMENU_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>
using namespace std;

class MainWindow {
public:
	void WindowUpdate();
};

void MainWindow::WindowUpdate()
{
	sf::RenderWindow window(sf::VideoMode(1024, 720), "Main Window", sf::Style::Default);

	sf::RectangleShape Background;
	Background.setSize(sf::Vector2f(1024, 720));
	sf::Texture MainTexture;
	MainTexture.loadFromFile("gameover.jpg");
	Background.setTexture(&MainTexture);

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				window.close();
			}
			
			window.clear();
			window.draw(Background);
			window.display();
		}
	}
}



#endif // MAINMENU_H
