#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "map.h"
#include "grid.h"
#include "textures.h"
#include"AVL.h"
//#include"path.h"
#include"gameover.h"
#include"win.h"
#include "menu.h"
#include <iostream>
using namespace sf;
using namespace std;

const int Max = 10;
int coinscollected = 0;
int coins = 0;
int swords = 0;
int potion = 0;
int keys = 0;
int progress = 100;
AVLTree<int> tree;

bool killenemy = false;
bool killenemy1 = false;
bool killenemy2 = false;


class information {
private:
    sf::Font font;
    sf::Text info[Max];

public:
    information(float width, float height);
    void draw(sf::RenderWindow& window, int x);
    void draw1(sf::RenderWindow& window, int x);
    void draw2(sf::RenderWindow& window, int x);
    void draw3(sf::RenderWindow& window, int x);
    void draw4(sf::RenderWindow& window, int x);
    void draw5(sf::RenderWindow& window, int x);
    void draw6(sf::RenderWindow& window, int x);
    void draw7(sf::RenderWindow& window, int x);
    //void Update();

};

information::information(float width, float height)
{
    if (!font.loadFromFile("britannic.ttf"))
    {
        cout << "Font Not Avalaible..!";
    }

    //x axis
    //y axis

    //Exit Button
    info[0].setFont(font);
    info[0].setFillColor(sf::Color::White);
    info[0].setString("Progress");
    info[0].setCharacterSize(50);
    info[0].setPosition(1030, 100);

    //Play Button
    info[1].setFont(font);
    info[1].setFillColor(sf::Color::Red);
    info[1].setString("Health");
    info[1].setCharacterSize(50);
    info[1].setPosition(1030, 260);


    //Option Button
    info[2].setFont(font);
    info[2].setFillColor(sf::Color::Yellow);
    info[2].setString("Points");
    info[2].setCharacterSize(50);
    info[2].setPosition(1030, 400);

    //About Button
    info[3].setFont(font);
    info[3].setFillColor(sf::Color::Cyan);
    info[3].setString("Inventory");
    info[3].setCharacterSize(50);
    info[3].setPosition(1030, 550);

    info[4].setFont(font);
    info[4].setFillColor(sf::Color::White);
    info[4].setString("");
    info[4].setCharacterSize(30);
    info[4].setPosition(1100, 700);

    info[6].setFont(font);
    info[6].setFillColor(sf::Color::Cyan);
    info[6].setString("");
    info[6].setCharacterSize(50);
    info[6].setPosition(1100, 610);

    info[7].setFont(font);
    info[7].setFillColor(sf::Color::Cyan);
    info[7].setString("");
    info[7].setCharacterSize(50);
    info[7].setPosition(1100, 680);

    info[8].setFont(font);
    info[8].setFillColor(sf::Color::Cyan);
    info[8].setString("");
    info[8].setCharacterSize(50);
    info[8].setPosition(1100, 755);

    info[9].setFont(font);
    info[9].setFillColor(sf::Color::Cyan);
    info[9].setString("");
    info[9].setCharacterSize(50);
    info[9].setPosition(1100, 820);

    info[5].setFont(font);
    info[5].setFillColor(sf::Color::White);
    info[5].setString(" ");
    info[5].setCharacterSize(50);
    info[5].setPosition(1050, 330);

}

void information::draw1(sf::RenderWindow& window, int coins)
{
    // Update the text for "Coins Collected"
    info[0].setString("Coins: " + std::to_string(coins));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

void information::draw2(sf::RenderWindow& window, int swords)
{
    // Update the text for "Coins Collected"
    info[4].setString("" + std::to_string(swords));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

// for health
void information::draw3(sf::RenderWindow& window, int x)
{
    // Update the text for "Coins Collected"
    info[5].setString(" " + std::to_string(progress) + "%");

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}


void information::draw(sf::RenderWindow& window, int coinsCollected)
{
    // Update the text for "Coins Collected"
    info[2].setString("Points: " + std::to_string(coinsCollected));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

// for inventory keys
void information::draw4(sf::RenderWindow& window, int x)
{
    info[6].setString(" " + std::to_string(coins));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

// for inventory swords
void information::draw5(sf::RenderWindow& window, int x)
{
    info[7].setString(" " + std::to_string(swords));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

// for inventory potions
void information::draw6(sf::RenderWindow& window, int x)
{
    info[8].setString(" " + std::to_string(potion));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}

void information::draw7(sf::RenderWindow& window, int x)
{
    info[9].setString(" " + std::to_string(keys));

    for (int i = 0; i < Max; ++i)
    {
        window.draw(info[i]);
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main()
{
    AVLTree<int> tree;
    srand(time(0) * 1000);
    RenderWindow window(VideoMode(1600, 1000), "SFML Game Grid");
    information info(1600, 1000);
    Clock clock;
    float delay = 0.25f;

    //LOAD ALL TEXTURES
    LoadTextures();

    //INVENTORY ITEMS COUNT
    int coincount = 10;
    int swordcount = 3;
    int portioncount = 2;
    int key = 4;

    //INITIAL PLAYER COORDINATES
    int playerX = 2;
    int playerY = 2;

    //INITIAL ENEMY COORDINATES
    int enemyX = 18;
    int enemyY = 18;

    //INITIAL ENEMY COORDINATES
    int enemy1X = 22;
    int enemy1Y = 5;
    //INITIAL ENEMY COORDINATES
    int enemy2X = 3;
    int enemy2Y = 22;

    //SPRITES
    Sprite tileSprite(tileTexture);
    Sprite sprite(tileTexture2);
    Sprite playerSprite(tileTexture3);

    Sprite CoinSprite(tileTexture5);
    Sprite SwordSprite(tileTexture6);
    Sprite PotionSprite(tileTexture7);

    Sprite EnemySprite(tileTexture4);
    Sprite Enemy1Sprite(tileTexture8);
    Sprite Enemy2Sprite(tileTexture9);

    Sprite coinSprite(inventory1);
    Sprite portionSprite(inventory3);
    Sprite swordSprite(inventory2);
    Sprite keySprite(inventory4);
    Sprite keySprite2(inventory4);


    Sprite sprite1(texture1);
    Sprite sprite2(texture2);
    Sprite bar(texture5);
    Sprite barfillSprite(texture6);

    int barfill_hor = 1090;
    int barfill_vert = 180;
    barfillSprite.setPosition(barfill_hor, barfill_hor);
    barfillSprite.setScale(3.5, 1);


    Sprite endSprite(texture3);
    Sprite hintSprite(texture4);

    //bar
    bar.setPosition(1050, 180);
    bar.setScale(1.7, 1.7);

    //coin
    sprite1.setPosition(1370, 410);
    sprite1.setScale(0.15, 0.15);

    //health
    sprite2.setPosition(1180, 260);
    sprite2.setScale(0.25, 0.25);

    //enemy
    EnemySprite.setScale(0.18, 0.1);

    //SET INITIAL POSITION
    playerSprite.setPosition(playerX * 40, playerY * 40);

    EnemySprite.setPosition(enemyX * 40, enemyY * 40);

    Enemy1Sprite.setPosition(enemy1X * 40, enemy1Y * 40);

    Enemy2Sprite.setPosition(enemy2X * 40, enemy2Y * 40);

    CoinSprite.setPosition(1020, 620);
    CoinSprite.setScale(0.15, 0.15);

    SwordSprite.setPosition(1020, 680);
    SwordSprite.setScale(1.45, 1.45);

    PotionSprite.setPosition(1020, 760);
    PotionSprite.setScale(1.45, 1.45);

    keySprite.setPosition(1030, 830);
    keySprite.setScale(1, 1);

    keySprite2.setPosition(1030, 830);
    keySprite2.setScale(1.2, 1.2);

    sf::SoundBuffer buffer;
    if (!buffer.loadFromFile("music1.ogg"))
    {
        // Handle error loading sound
        return -1;
    }

    // Create the sound
    sf::Sound sound;
    sound.setBuffer(buffer);
    sound.setVolume(50);

    //sound for fire

    sf::SoundBuffer buffer1;
    if (!buffer1.loadFromFile("music2.ogg"))
    {
        // Handle error loading sound
        return -1;
    }

    // Create the sound
    sf::Sound sound1;
    sound1.setBuffer(buffer1);
    sound1.setVolume(200);

    // sound for coins
    sf::SoundBuffer buffer2;
    if (!buffer2.loadFromFile("sound_coin.ogg"))
    {
        // Handle error loading sound
        return -1;
    }

    // Create the sound
    sf::Sound sound2;
    sound2.setBuffer(buffer2);
    sound2.setVolume(100);


    //GENERATE BLOCKS AND INVENTORY ITEMS
    for (int i = 0; i < gridWidth; i++) {
        for (int j = 0; j < gridHeight; j++) {

            if (rand() / (float)RAND_MAX < 0.21f || i == 0 || j == 0 || i == gridWidth - 1 || j == gridHeight - 1)
            {
                int blocktype = gameMap[i + j * gridWidth];
                if (blocktype == 10 ||
                    blocktype == 20 ||
                    blocktype == 30 ||
                    blocktype == 5 ||
                    blocktype == 2 ||
                    blocktype == 3)
                    continue;

                gameMap[i + j * gridWidth] = 0;
            }
        }
    }

    for (int i = 22; i < gridWidth - 1; i++) {
        for (int j = 22; j < gridHeight - 1; j++) {
            gameMap[i + j * gridWidth] = 1;
        }
    }


    //sound.play();


    //Pair src = make_pair(2, 2);

    //// Destination is the left-most top-most corner
    //Pair dest = make_pair(22, 22);

    //aStarSearch(gameMap, src, dest);
    Texture MainTexture;
    MainTexture.loadFromFile("gameover.jpg");
    RectangleShape Background;
    Background.setTexture(&MainTexture);

    Texture MainTexture2;
    MainTexture2.loadFromFile("gameover.jpg");
    RectangleShape Background2;
    Background2.setTexture(&MainTexture2);

    MainMenu mainMenu;
    mainMenu.run();

    while (window.isOpen())
    {

        Event event;
        //---Event Listening Part---//
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            else if (event.type == sf::Event::KeyPressed)
            {

                for (int i = 0; i < gridWidth; i++) {
                    for (int j = 0; j < gridHeight; j++) {
                        if (gameMap[i * gridWidth + j] == 9)
                            gameMap[i * gridWidth + j] = 1;
                    }
                }
                switch (event.key.code)
                {
                case sf::Keyboard::Up:
                    if (gameMap[gridWidth * (playerY - 1) + playerX] != 0)
                        playerY -= 1;
                    if (gameMap[playerX + playerY * gridWidth] == 10)
                    {
                        sound2.play();
                        tree.insert(10);
                        coins++;
                        tree.updateCoinsCount(10, coins);
                        coinscollected += 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 20)
                    {
                        sound2.play();
                        tree.insert(20);
                        swords++;
                        cout << "\nTOTAL SWORDS : " << swords << endl;
                        tree.updateSwordsCount(20, swords);
                        coinscollected += 20;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 30)
                    {
                        sound2.play();
                        tree.insert(30);
                        potion++;
                        tree.updatePotionCount(30, potion);
                        coinscollected += 30;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 3)
                    {
                        sound2.play();
                        tree.insert(3);
                        keys++;
                        tree.updatekeyCount(3, keys);
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 2)
                    {
                        //sound.pause();
                        progress = progress - 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        sound1.play();
                    }
                    break;

                case sf::Keyboard::Down:
                    if (gameMap[gridWidth * (playerY + 1) + playerX] != 0)
                        playerY += 1;
                    if (gameMap[playerX + playerY * gridWidth] == 10)
                    {
                        sound2.play();
                        tree.insert(10);
                        coins++;
                        tree.updateCoinsCount(10, coins);
                        coinscollected += 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 20)
                    {
                        sound2.play();
                        tree.insert(20);
                        swords++;
                        cout << "\nTOTAL SWORDS : " << swords << endl;
                        tree.updateSwordsCount(20, swords);
                        coinscollected += 20;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 30)
                    {
                        sound2.play();
                        tree.insert(30);
                        potion++;
                        tree.updatePotionCount(30, potion);
                        coinscollected += 30;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 3)
                    {
                        sound2.play();
                        tree.insert(3);
                        keys++;
                        tree.updatekeyCount(3, keys);
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 2)
                    {
                        //sound.pause();
                        progress = progress - 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        sound1.play();
                    }
                    break;

                case sf::Keyboard::Right:
                    if (gameMap[gridWidth * (playerY)+(playerX + 1)] != 0)
                        playerX += 1;
                    if (gameMap[playerX + playerY * gridWidth] == 10)
                    {
                        sound2.play();
                        tree.insert(10);
                        coins++;
                        tree.updateCoinsCount(10, coins);
                        coinscollected += 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 20)
                    {
                        sound2.play();
                        tree.insert(20);
                        swords++;
                        cout << "\nTOTAL SWORDS : " << swords << endl;
                        tree.updateSwordsCount(20, swords);
                        coinscollected += 20;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 30)
                    {
                        sound2.play();
                        tree.insert(30);
                        potion++;
                        tree.updatePotionCount(30, potion);
                        coinscollected += 30;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 3)
                    {
                        sound2.play();
                        tree.insert(3);
                        keys++;
                        tree.updatekeyCount(3, keys);
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 2)
                    {
                        //sound.pause();
                        progress = progress - 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        sound1.play();
                    }
                    break;

                case sf::Keyboard::Left:
                    if (gameMap[gridWidth * (playerY)+(playerX - 1)] != 0)
                        playerX -= 1;
                    if (gameMap[playerX + playerY * gridWidth] == 10)
                    {
                        sound2.play();
                        tree.insert(10);
                        coins++;
                        tree.updateCoinsCount(10, coins);
                        coinscollected += 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 20)
                    {
                        sound2.play();
                        tree.insert(gridWidth);
                        swords++;
                        cout << "\nTOTAL SWORDS : " << swords << endl;
                        tree.updateSwordsCount(20, swords);
                        coinscollected += 20;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 30)
                    {
                        sound2.play();
                        tree.insert(30);
                        potion++;
                        tree.updatePotionCount(30, potion);
                        coinscollected += 30;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 3)
                    {
                        sound2.play();
                        tree.insert(3);
                        keys++;
                        tree.updatekeyCount(3, keys);
                        gameMap[playerX + playerY * gridWidth] = 1;
                        info.draw(window, coinscollected);
                        window.display();
                    }
                    else if (gameMap[playerX + playerY * gridWidth] == 2)
                    {
                        //sound.pause();
                        progress = progress - 10;
                        gameMap[playerX + playerY * gridWidth] = 1;
                        sound1.play();
                    }
                    break;

                }
                if (swords > 0)
                {
                    if ((playerSprite.getPosition()) == (EnemySprite.getPosition()))
                    {
                        swords--;
                        killenemy = true;
                    }
                    else if ((playerSprite.getPosition()) == (Enemy1Sprite.getPosition()))
                    {
                        swords--;
                        killenemy1 = true;
                    }
                    else if ((playerSprite.getPosition()) == (Enemy2Sprite.getPosition()))
                    {
                        swords--;
                        killenemy2 = true;
                    }
                }
                if (progress == 0)
                {
                    sound1.play();
                    window.close();
                }


            }
            //UPDATE PLAYER POSITION
            playerSprite.setPosition(playerX * 40.f, playerY * 40.f);
            int count = 0;

            if (swords <= 0)
            {
                if ((playerSprite.getPosition()) == (EnemySprite.getPosition()))
                {
                    MainWindow gameover;
                    gameover.WindowUpdate();
                    window.close();
                }
                if ((playerSprite.getPosition()) == (Enemy1Sprite.getPosition()))
                {
                    MainWindow gameover;
                    gameover.WindowUpdate();
                    window.close();
                }

                if ((playerSprite.getPosition()) == (Enemy2Sprite.getPosition()))
                {
                    MainWindow gameover;
                    gameover.WindowUpdate();
                    window.close();
                }
            }

            if (playerX == 24 && playerY == 22)
            {
                WinWindow gamewon;
                gamewon.WindowUpdate();
                window.close();
            }

            if (tree.getkeyCount(3) >= 4)
            {
                if (count == 0)
                {
                    gameMap[24 + 22 * gridWidth] = 1;
                    count++;
                }
                Pair src = make_pair(playerY, playerX);

                // Destination is the left-most top-most corner
                Pair dest = make_pair(22, 24); //(row,col)

                aStarSearch(gameMap, src, dest);
            }


        }

        if (clock.getElapsedTime().asSeconds() > delay)
        {
            clock.restart();
            // ENEMY MOVEMENT
            int ex1 = EnemySprite.getPosition().x;
            int ey1 = EnemySprite.getPosition().y;

            int ex2 = Enemy1Sprite.getPosition().x;
            int ey2 = Enemy1Sprite.getPosition().y;

            int ex3 = Enemy2Sprite.getPosition().x;
            int ey3 = Enemy2Sprite.getPosition().y;

            int px = playerSprite.getPosition().x;
            int py = playerSprite.getPosition().y;

            // Calculate differences in positions along both axes
            int dx1 = px - ex1;
            int dy1 = py - ey1;

            int dx2 = px - ex2;
            int dy2 = py - ey2;

            int dx3 = px - ex3;
            int dy3 = py - ey3;

            //enemy x and y
            enemyX = ex1 / 40;
            enemyY = ey1 / 40;

            enemy1X = ex2 / 40;
            enemy1Y = ey2 / 40;

            enemy2X = ex3 / 40;
            enemy2Y = ey3 / 40;


            // Determine which axis to move along (choose the axis with the greater difference)
            if (abs(dx1) > abs(dy1))
            {
                // Move along the horizontal axis
                if (dx1 > 0) {
                    // Move right
                    if (gameMap[(enemyX + 1) + enemyY * gridWidth] != 0)
                        ex1 += tileSize;
                }
                else {
                    // Move left
                    if (gameMap[(enemyX - 1) + enemyY * gridWidth] != 0)
                        ex1 -= tileSize;
                }
            }
            else
            {
                // Move along the vertical axis
                if (dy1 > 0)
                {
                    // Move down
                    if (gameMap[enemyX + (enemyY + 1) * gridWidth] != 0)
                        ey1 += tileSize;
                }
                else
                {
                    // Move up
                    if (gameMap[enemyX + (enemyY - 1) * gridWidth] != 0)
                        ey1 -= tileSize;
                }
            }

            if (abs(dx2) > abs(dy2))
            {
                // Move along the horizontal axis
                if (dx2 > 0) {
                    // Move right
                    if (gameMap[(enemy1X + 1) + enemy1Y * gridWidth] != 0)
                        ex2 += tileSize;
                }
                else {
                    // Move left
                    if (gameMap[(enemy1X - 1) + enemy1Y * gridWidth] != 0)
                        ex2 -= tileSize;
                }
            }
            else
            {
                // Move along the vertical axis
                if (dy2 > 0)
                {
                    // Move down
                    if (gameMap[enemy1X + (enemy1Y + 1) * gridWidth] != 0)
                        ey2 += tileSize;
                }
                else
                {
                    // Move up
                    if (gameMap[enemy1X + (enemy1Y - 1) * gridWidth] != 0)
                        ey2 -= tileSize;
                }
            }

            if (abs(dx3) > abs(dy3))
            {
                // Move along the horizontal axis
                if (dx3 > 0) {
                    // Move right
                    if (gameMap[(enemy2X + 1) + enemy2Y * gridWidth] != 0)
                        ex3 += tileSize;
                }
                else {
                    // Move left
                    if (gameMap[(enemy2X - 1) + enemy2Y * gridWidth] != 0)
                        ex3 -= tileSize;
                }
            }
            else
            {
                // Move along the vertical axis
                if (dy3 > 0)
                {
                    // Move down
                    if (gameMap[enemy2X + (enemy2Y + 1) * gridWidth] != 0)
                        ey3 += tileSize;
                }
                else
                {
                    // Move up
                    if (gameMap[enemy2X + (enemy2Y - 1) * gridWidth] != 0)
                        ey3 -= tileSize;
                }
            }

            // Update enemy position

            EnemySprite.setPosition(ex1, ey1);
            Enemy1Sprite.setPosition(ex2, ey2);
            Enemy2Sprite.setPosition(ex3, ey3);

        }



        //CLEAR WINDOW
        window.clear();



        //DRAW EVERYTHING
        for (int i = 0; i < gridWidth; ++i) {
            for (int j = 0; j < gridHeight; ++j)
            {
                int tileType = gameMap[i * gridWidth + j]; // Get tile type from gameMap array

                // Only draw if tileType is 0
                if (tileType == 0)
                {
                    // Set position of tile sprite
                    tileSprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(tileSprite);
                }
                else if (tileType == 2)
                {
                    sprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(sprite);
                }
                else if (tileType == 10)
                {
                    coinSprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(coinSprite);
                }
                else if (tileType == 20)
                {
                    swordSprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(swordSprite);
                }
                else if (tileType == 30)
                {
                    portionSprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(portionSprite);
                }
                else if (tileType == 5)
                {
                    endSprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(endSprite);
                }
                else if (tileType == 9)
                {
                    hintSprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(hintSprite);
                }
                else if (tileType == 3)
                {
                    keySprite.setPosition(j * tileSize, i * tileSize);
                    window.draw(keySprite);
                }
                else if (tileType == 2)
                {
                    progress = progress - 10;
                }
            }
        }

        window.draw(playerSprite);

        if (!killenemy)
        {
            window.draw(EnemySprite);
        }
        else
            EnemySprite.setPosition(40 * 40, 40 * 40);

        if (!killenemy1)
        {
            window.draw(Enemy1Sprite);
        }
        else
            Enemy1Sprite.setPosition(40 * 40, 40 * 40);

        if (!killenemy2)
        {
            window.draw(Enemy2Sprite);
        }
        else
            Enemy2Sprite.setPosition(40 * 40, 40 * 40);

        info.draw(window, coinscollected);
        if (tree.getCoinsCount(10) > 0)
        {
            window.draw(CoinSprite);
            info.draw4(window, tree.getCoinsCount(10));
        }

        if (tree.getSwordsCount(20) > 0)
        {
            window.draw(SwordSprite);
            info.draw5(window, tree.getSwordsCount(20));
        }

        if (tree.getPotionCount(30) > 0)
        {
            window.draw(PotionSprite);
            info.draw6(window, tree.getPotionCount(30));
        }

        if (tree.getkeyCount(3) > 0)
        {
            window.draw(keySprite2);
            info.draw7(window, tree.getkeyCount(3));
        }

        window.draw(sprite1);
        window.draw(sprite2);
        window.draw(bar);
        // window.draw(barfillSprite);
        for (int i = 0; i < keys; i++)
        {
            barfillSprite.setPosition(1050 + (i * 70), 185);
            window.draw(barfillSprite);
        }
        info.draw3(window, progress);

        window.display();
    }

    return 0;
}
